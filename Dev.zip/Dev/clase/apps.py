from django.apps import AppConfig


class ClaseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'clase'
